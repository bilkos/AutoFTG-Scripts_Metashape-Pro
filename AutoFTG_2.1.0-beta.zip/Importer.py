# -*- coding: utf-8 -*-
from AutoFTG import auto_cal_mark_coord
